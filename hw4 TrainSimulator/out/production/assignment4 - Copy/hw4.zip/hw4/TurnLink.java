package hw4;

import api.Point;


public class TurnLink extends AbstractLink
{
    /**
     * The first end point
     */
    private Point endPointA;
    /**
     * The second end point
     */
    private Point endPointB;
    /**
     * The third end point
     */
    private Point endPointC;

    public TurnLink(Point endpointA, Point endpointB, Point endpointC) {
        this.endPointA = endpointA;
        this.endPointB = endpointB;
        this.endPointC = endpointC;
    }

    /**
     * @author Prerak
     */
    @Override
    public Point getConnectedPoint(Point point) {

        if(point == endPointA){
            return endPointC;
        }
        else {
            return endPointA;
        }

    }

    /**
     * @author Prerak
     */
    @Override
    public int getNumPaths() {
        return 3;
    }


}