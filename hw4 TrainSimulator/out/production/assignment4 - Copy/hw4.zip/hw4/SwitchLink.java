package hw4;

import api.Point;

public class SwitchLink extends AbstractLink
{
    /**
     * The first end point
     */
    private Point endPointA;
    /**
     * The second end point
     */
    private Point endPointB;
    /**
     * The third end point
     */
    private Point endPointC;

    private boolean turn;
    private boolean trainEnteredCrossing;
    public SwitchLink(Point endpointA, Point endpointB, Point endpointC){
        this.endPointA = endpointA;
        this.endPointB = endpointB;
        this.endPointC = endpointC;
    }

    /**
    * @author Prerak
     */

    public void setTurn (boolean turn){
        this.turn = turn;
    }

    /**
    * @author Prerak
     */
    @Override
    public int getNumPaths() {
        return 3;
    }

    /**
    * @author Prerak
     */
    @Override
    public void trainEnteredCrossing() {
        trainEnteredCrossing = true;
    }

    /**
    * @author Prerak
     */
    @Override
    public void trainExitedCrossing() {
        trainEnteredCrossing = false;
    }

    /**
    * @author Prerak
     */
    @Override
    public Point getConnectedPoint(Point point) {

        if(!turn && !trainEnteredCrossing) {
            if (point == endPointA) {
                return endPointB;
            } else {
                return endPointA;
            }
        }
        else {
            if(point == endPointA){
                return endPointC;
            }
            else {
                return endPointA;
            }
        }
    }

}